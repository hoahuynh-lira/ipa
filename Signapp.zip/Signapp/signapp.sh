#!/bin/bash
set -e
rm -r ipa || true
mkdir ipa
cd ipa
wget [link_app_ipa]
unzip [App_name].ipa

rm -r deb || true
mkdir -p deb/Applications
cp -a DEBIAN deb/
cp -a ipa/Payload/[App].app deb/Applications
codesign -s "Worth Doing Badly iPhone OS Application Signing" -f --entitlements=signapp.entitlements deb/Applications/[App].app
dpkg-deb --root-owner-group -b deb [Name_deb].deb
